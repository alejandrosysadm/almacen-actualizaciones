'use strict';
const need = require('../lib/build-info.json').node;
if (process.version !== need) { console.error('Esta versión necesita Node ' + need + ' (tienes ' + process.version + ').'); process.exit(1); }
require('bytenode');
require('./admin.jsc');
