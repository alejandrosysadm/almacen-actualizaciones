'use strict';
const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
let dataDir = process.env.DATA_DIR;
if (!dataDir) { try { const m = /^\s*DATA_DIR\s*=\s*(.+)$/m.exec(fs.readFileSync(path.join(__dirname, '.env'), 'utf8')); if (m) dataDir = m[1].trim().replace(/^["']|["']$/g, ''); } catch {} }
const flag = path.join(path.resolve(__dirname, dataDir || 'data'), 'actualizacion.json');
try {
  const u = JSON.parse(fs.readFileSync(flag, 'utf8'));
  if (u.pendiente && !u.revertida) {
    u.intentos = (u.intentos || 0) + 1;
    if (u.intentos > 3 && u.programa && fs.existsSync(u.programa)) {
      const keep = new Set(['data', 'backups', 'certs', 'logs', 'node_modules', '.env']);
      for (const e of fs.readdirSync(__dirname)) if (!keep.has(e)) fs.rmSync(path.join(__dirname, e), { recursive: true, force: true });
      execFileSync('tar', ['-xzf', u.programa], { cwd: __dirname });
      u.revertida = true; fs.writeFileSync(flag, JSON.stringify(u, null, 2));
      console.error('La versión ' + u.hacia + ' no arranca: se ha restaurado la ' + u.desde + '.'); process.exit(1);
    }
    fs.writeFileSync(flag, JSON.stringify(u, null, 2));
  }
} catch {}
const need = require('./lib/build-info.json').node;
if (process.version !== need) { console.error('Esta versión necesita Node ' + need + ' (tienes ' + process.version + ').'); process.exit(1); }
require('bytenode');
require('./server.jsc');
