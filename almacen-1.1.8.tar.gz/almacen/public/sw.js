/* Service worker de la PWA «Almacén».
 * Objetivos: que la web sea instalable y abra rápido, sin servir versiones viejas tras actualizar
 * y sin tocar nunca la API ni el canal en tiempo real (SSE). */
const CACHE = 'almacen-pwa-v1';
const CORE = ['./', 'app.js', 'app.css', 'boot.js', 'splash.js', 'favicon.svg', 'icon-192.png', 'icon-512.png', 'vendor/qrcode.min.js'];

self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE).catch(() => {})));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  // Nunca interceptar la API ni el canal en tiempo real: deben ir siempre a la red.
  if (url.pathname.startsWith('/api/') || url.pathname === '/events') return;

  const isNav = req.mode === 'navigate';
  const netFirst = isNav || url.pathname === '/' || /\.(js|css)$/.test(url.pathname) || url.pathname.endsWith('.webmanifest');

  if (netFirst) {
    // Red primero (para recoger la versión nueva tras una actualización); si no hay red, lo cacheado.
    e.respondWith(
      fetch(req).then(r => { if (r && r.ok) { const c = r.clone(); caches.open(CACHE).then(ca => ca.put(req, c)); } return r; })
        .catch(() => caches.match(req).then(m => m || caches.match('./')))
    );
  } else {
    // Estáticos (fuentes, iconos, imágenes): caché primero, y si no, red.
    e.respondWith(
      caches.match(req).then(m => m || fetch(req).then(r => { if (r && r.ok) { const c = r.clone(); caches.open(CACHE).then(ca => ca.put(req, c)); } return r; }))
    );
  }
});
